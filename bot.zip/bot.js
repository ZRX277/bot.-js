// bot.js — Claire Bot (Termux-ready) — Single fake player + improved UI & checks
// Dependencies:
//   npm install node-telegram-bot-api bedrock-protocol pretty-ms rcon-client
// Place this file next to a folder data/ (will be created if missing).

const TelegramBot = require('node-telegram-bot-api');
const { createClient } = require('bedrock-protocol');
const fs = require('fs');
const path = require('path');
const net = require('net');
const prettyMs = require('pretty-ms');

let rconClientAvailable = false;
let Rcon;
try { Rcon = require('rcon-client').Rcon; rconClientAvailable = true; } catch (e) { rconClientAvailable = false; }

// ====== CONFIG & FILES ======
const DATA_DIR = path.join(__dirname, 'data');
if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });

const CONFIG_FILE = path.join(DATA_DIR, 'config.json');
const USERS_FILE = path.join(DATA_DIR, 'users.json');
const SERVERS_FILE = path.join(DATA_DIR, 'servers.json');
const BANS_FILE = path.join(DATA_DIR, 'bans.json');
const LOG_FILE = path.join(DATA_DIR, 'bot.log');

// default config (written if config.json missing)
const DEFAULT_CFG = {
  token: "7638511217:AAGOUDmuEkFZw9SVOlqytmhmQyaOi2lqsGA",
  ownerId: 6978213389,
  requiredChannels: ["@ZR_24R", "@vvujw", "@vcrtewFT"],
  admins: [],
  activationCode: null,
  activatedChats: {},
  virtualUsersCount: 520000,
  defaultPlayers: ["ZR_3BRO"],
  welcomeImage: "https://j.top4top.io/p_3601g5j3b0.jpg",
  defaultBedrockVersion: "1.21.120"
};

// load or write config
let config = DEFAULT_CFG;
try {
  if (fs.existsSync(CONFIG_FILE)) {
    const raw = fs.readFileSync(CONFIG_FILE,'utf8');
    const parsed = JSON.parse(raw || '{}');
    config = Object.assign({}, DEFAULT_CFG, parsed);
  } else {
    fs.writeFileSync(CONFIG_FILE, JSON.stringify(DEFAULT_CFG, null, 2), 'utf8');
    config = DEFAULT_CFG;
  }
} catch(e) {
  try { fs.writeFileSync(CONFIG_FILE, JSON.stringify(DEFAULT_CFG, null, 2), 'utf8'); } catch(e){}
  config = DEFAULT_CFG;
}

const TOKEN = process.env.TG_TOKEN || config.token;
const OWNER_ID = Number(process.env.OWNER_ID || config.ownerId);
const REQUIRED_CHANNELS = config.requiredChannels || DEFAULT_CFG.requiredChannels;
const PLAYER_NAMES = Array.isArray(config.defaultPlayers) && config.defaultPlayers.length ? config.defaultPlayers : DEFAULT_CFG.defaultPlayers;
const WELCOME_IMG = config.welcomeImage || DEFAULT_CFG.welcomeImage;

// runtime constants
const AUTO_RETRY_MIN = 1;
const MESSAGE_WINDOW_MS = 10 * 1000;
const MESSAGE_LIMIT = 5;
const SAVE_INTERVAL_MS = 30 * 1000;
const BAN_LEVELS = [3*60*1000, 10*60*1000, 60*60*1000, 24*60*60*1000, 7*24*60*60*1000];

// ====== helpers ======
const safeReadJson = (file, def = {}) => { try { return fs.existsSync(file) ? JSON.parse(fs.readFileSync(file,'utf8')) : def; } catch(e) { return def; } };
const safeWriteJson = (file, data) => { try { fs.writeFileSync(file, JSON.stringify(data, null, 2), 'utf8'); } catch(e) { console.error('write err', file, e); } };

let users = safeReadJson(USERS_FILE, {});
let servers = safeReadJson(SERVERS_FILE, {});
let bans = safeReadJson(BANS_FILE, {});
safeWriteJson(CONFIG_FILE, config);

function log(...args) {
  const line = `[${new Date().toISOString()}] ${args.map(a => (typeof a === 'string' ? a : JSON.stringify(a))).join(' ')}\n`;
  try { fs.appendFileSync(LOG_FILE, line); } catch(e){}
  console.log(...args);
}

// ====== bot init ======
if (!TOKEN || TOKEN === 'PUT_YOUR_TOKEN_HERE') {
  console.error('ERROR: Please set TG_TOKEN env or edit data/config.json token field.');
  process.exit(1);
}

let bot;
try {
  bot = new TelegramBot(TOKEN, { polling: true });
} catch (error) {
  console.error('Failed to initialize bot:', error.message);
  process.exit(1);
}

// periodic save
function saveAll(){ try { safeWriteJson(USERS_FILE, users); safeWriteJson(SERVERS_FILE, servers); safeWriteJson(BANS_FILE, bans); safeWriteJson(CONFIG_FILE, config); } catch(e){ log('saveAll err', e); } }
setInterval(saveAll, SAVE_INTERVAL_MS);

// runtime maps
const flows = {};
const versionMenuMap = {};
const active = {};
const msgTracker = {};

// ====== spam protection ======
function liftBanIfExpired(userId) { const b = bans[userId]; if (!b) return; if (b.bannedUntil && b.bannedUntil <= Date.now()) { delete bans[userId]; saveAll(); } }
function isBanned(userId) { const b = bans[userId]; return b && b.bannedUntil && b.bannedUntil > Date.now(); }
function banRemainingMs(userId) { const b = bans[userId]; if (!b) return 0; return Math.max(0, b.bannedUntil - Date.now()); }
function escalateBan(userId) {
  if (Number(userId) === Number(OWNER_ID)) return 0;
  const now = Date.now();
  let entry = bans[userId] || { level: -1, bannedUntil: 0 };
  entry.level = Math.min(entry.level + 1, BAN_LEVELS.length - 1);
  const dur = BAN_LEVELS[entry.level];
  entry.bannedUntil = now + dur;
  bans[userId] = entry;
  saveAll();
  log('escalateBan', userId, entry);
  return dur;
}
async function handleSpamProtection(msg) {
  const userId = String(msg.from.id);
  if (Number(userId) === Number(OWNER_ID) || (config.admins||[]).includes(Number(userId))) return { blocked: false };
  liftBanIfExpired(userId);
  if (isBanned(userId)) return { blocked: true, remainMs: banRemainingMs(userId) };
  const now = Date.now();
  msgTracker[userId] = msgTracker[userId] || [];
  msgTracker[userId] = msgTracker[userId].filter(ts => now - ts <= MESSAGE_WINDOW_MS);
  msgTracker[userId].push(now);
  if (msgTracker[userId].length > MESSAGE_LIMIT) {
    const dur = escalateBan(userId);
    return { blocked: true, newlyBanned: true, durMs: dur };
  }
  return { blocked: false };
}
setInterval(() => {
  const now = Date.now();
  for (const uid of Object.keys(msgTracker)) {
    msgTracker[uid] = msgTracker[uid].filter(ts => now - ts <= MESSAGE_WINDOW_MS);
    if (msgTracker[uid].length === 0) delete msgTracker[uid];
  }
  for (const uid of Object.keys(bans)) liftBanIfExpired(uid);
  saveAll();
}, 5000);

// ====== network helper ======
function checkServerOnline(host, port, timeout = 3000) {
  return new Promise((resolve) => {
    const sock = new net.Socket();
    let done = false;
    const fail = () => { if (!done) { done = true; try { sock.destroy(); } catch{}; resolve(false); } };
    sock.setTimeout(timeout, fail);
    sock.once('error', fail);
    sock.connect(port || 19132, host, () => { if (!done) { done = true; try { sock.end(); } catch{}; resolve(true); } });
  });
}

// ====== simple validators ======
function isLikelyHost(str) {
  if (!str || typeof str !== 'string') return false;
  const trimmed = str.trim();
  const ipv4 = /^(\d{1,3}\.){3}\d{1,3}$/;
  const domain = /^[a-zA-Z0-9\-\.]+\.[a-zA-Z]{2,}$/;
  const hostOnlyPort = /^([a-zA-Z0-9\-\.]+)(:\d+)?$/;
  return ipv4.test(trimmed) || domain.test(trimmed) || hostOnlyPort.test(trimmed);
}
function sanitizeHost(str) { return (str || '').trim(); }

// ====== persistent UI helpers ======
const MAIN_INLINE_BASE = [
  [{ text: "➕ إضافة سيرفر", callback_data: "add_server" }],
  [{ text: "📂 سيرفراتي", callback_data: "my_servers" }],
  [{ text: "ℹ️ طريقة الاستخدام", callback_data: "howto" }],
];

async function sendPersistentPhoto(chatId, photoUrl, caption, opts = {}) {
  try {
    const res = await bot.sendPhoto(chatId, photoUrl, { caption, ...opts });
    users[chatId] = users[chatId] || {};
    users[chatId].lastPersistent = { chatId, message_id: res.message_id, isPhoto: true };
    saveAll();
    return res;
  } catch (e) { log('sendPersistentPhoto err', e); return null; }
}

async function sendPersistent(chatId, text, opts = {}) {
  try {
    const res = await bot.sendMessage(chatId, text, opts);
    users[chatId] = users[chatId] || {};
    users[chatId].lastPersistent = { chatId, message_id: res.message_id, isPhoto: false };
    saveAll();
    return res;
  } catch (e) { log('sendPersistent err', e); return null; }
}

async function editPersistent(chatId, text, opts = {}) {
  const last = users[chatId]?.lastPersistent;
  if (last && last.chatId === chatId && last.message_id) {
    try {
      if (last.isPhoto) {
        try { return await bot.editMessageCaption(text, { chat_id: chatId, message_id: last.message_id, ...opts }); } catch(e) {}
      }
      return await bot.editMessageText(text, { chat_id: chatId, message_id: last.message_id, ...opts });
    } catch (e) {
      return sendPersistent(chatId, text, opts);
    }
  } else {
    return sendPersistent(chatId, text, opts);
  }
}

// ✅ الدالة المفقودة تم إضافتها هنا
async function sendOrEditPersistent(chatId, text, opts = {}) {
  const last = users[chatId]?.lastPersistent;
  if (last && last.chatId === chatId && last.message_id) {
    try { 
      return await editPersistent(chatId, text, opts); 
    } catch(e) {
      return await sendPersistent(chatId, text, opts);
    }
  } else {
    return await sendPersistent(chatId, text, opts);
  }
}

async function sendEphemeral(chatId, text, opts = {}) {
  try {
    const res = await bot.sendMessage(chatId, text, opts);
    setTimeout(async () => { try { await bot.deleteMessage(chatId, res.message_id); } catch(e) {} }, 2200);
    return res;
  } catch (e) { log('sendEphemeral err', e); return null; }
}

// ====== bedrock client helpers ======
function cleanupClientKey(key) {
  const e = active[key]; if (!e) return;
  try { if (e.client) { e.client.removeAllListeners?.(); try { e.client.close(); } catch{} } } catch(_) {}
  try { if (e.retryTimer) clearTimeout(e.retryTimer); } catch(_) {}
  delete active[key];
}

function cleanupClientsForServer(chatId, serverId) {
  const prefix = `${chatId}:${serverId}:`;
  for (const key of Object.keys(active)) if (key.startsWith(prefix)) cleanupClientKey(key);
}

function anyActiveForServer(chatId, serverId) {
  const prefix = `${chatId}:${serverId}:`;
  for (const k of Object.keys(active)) if (k.startsWith(prefix) && active[k].client) return true;
  return false;
}

function scheduleRestart(chatId, serv, playerName) {
  const key = `${chatId}:${serv.id}:${playerName}`;
  cleanupClientKey(key);
  active[key] = active[key] || {};
  try { if (active[key].retryTimer) clearTimeout(active[key].retryTimer); } catch(_) {}
  active[key].retryTimer = setTimeout(() => createBedrockClient(serv, chatId, serv.id, playerName), AUTO_RETRY_MIN * 60 * 1000);
}

async function createSingleBedrockClient(serv, chatId, serverId, playerName) {
  const key = `${chatId}:${serverId}:${playerName}`;
  if (active[key] && active[key].client) return active[key].client;
  const options = {
    host: serv.host,
    port: serv.port || 19132,
    username: playerName,
    offline: true,
    skipPing: true,
    version: serv.version || config.defaultBedrockVersion || '1.21.120'
  };
  let client;
  try { client = createClient(options); } catch (e) {
    log('createBedrockClient error', playerName, e && e.message ? e.message : e);
    scheduleRestart(chatId, serv, playerName);
    return;
  }
  active[key] = { client, retryTimer: null };

  client.on('connect', async () => { log('client connect', key); });
  client.on('spawn', async () => {
    log('client spawn', key);
    try { await bot.sendMessage(chatId, `✅ تم دخول لاعب بنجاح ✅`); } catch(e){}
  });
  client.on('close', async (reason) => {
    log('client close', key, reason);
    cleanupClientKey(key);
    scheduleRestart(chatId, serv, playerName);
  });
  client.on('error', async (err) => {
    log('client error', key, err && err.message ? err.message : err);
    try { client.close(); } catch(_) {}
  });

  return client;
}

async function createBedrockClient(serv, chatId, serverId, playerName) {
  if (playerName) return createSingleBedrockClient(serv, chatId, serverId, playerName);
  const players = Array.isArray(serv.players) && serv.players.length ? serv.players : (config.defaultPlayers || PLAYER_NAMES);
  for (const p of players) try { await createSingleBedrockClient(serv, chatId, serverId, p); } catch(e){ log('createBedrockClient loop err', e); }
}

// ====== versions utility ======
const supportedVersions = {
  '1.21.121':860,'1.21.120':859,'1.21.111':844,'1.21.100':827,
  '1.21.93':819,'1.21.90':818,'1.21.80':800,'1.21.70':786,
  '1.21.60':776,'1.21.50':766,'1.21.42':748,'1.21.30':729,
  '1.21.20':712,'1.21.2':686,'1.21.0':685,'1.20.80':671
};

function getSortedVersions() {
  return Object.keys(supportedVersions).sort((a,b)=>{
    const pa = a.split('.').map(n=>parseInt(n)), pb = b.split('.').map(n=>parseInt(n));
    for (let i=0;i<Math.max(pa.length,pb.length);i++){ const va=pa[i]||0, vb=pb[i]||0; if(va!==vb) return vb - va; }
    return 0;
  });
}

// ====== activation helpers ======
function isActivatedChat(chatId) {
  if (Number(chatId) === Number(OWNER_ID)) return true;
  if (!config.activationCode) return true;
  return !!config.activatedChats[chatId];
}

// ====== notify owner helper ======
async function notifyOwnerNewUser(msgFrom) {
  try {
    const userId = msgFrom.id;
    const username = msgFrom.username ? `@${msgFrom.username}` : '—';
    const firstName = msgFrom.first_name || '';
    const totalReal = Object.keys(users).length;
    const totalVirtual = config.virtualUsersCount || 0;
    const txt = `تم دخول شخص جديد إلى البوت 👾\n• الاسم: ${firstName}\n• معرف: ${username}\n• الايدي: ${userId}\nعدد الأعضاء الكلي: ${totalReal + totalVirtual}`;
    try {
      const photos = await bot.getUserProfilePhotos(userId, { limit: 1 });
      if (photos && photos.total_count > 0 && photos.photos && photos.photos[0]) {
        const fileId = photos.photos[0][0].file_id;
        await bot.sendPhoto(OWNER_ID, fileId, { caption: txt });
        return;
      }
    } catch (e) {}
    await bot.sendMessage(OWNER_ID, txt);
  } catch (e) { log('notifyOwnerNewUser err', e); }
}

// ====== UI: server management ======
async function sendServerUI(chatId, serv) {
  const id = serv.id;
  const running = anyActiveForServer(chatId, id);
  const isOwner = Number(chatId) === Number(OWNER_ID);

  const kb = { inline_keyboard: [
    [{ text: running ? '⏹ إيقاف' : '▶ تشغيل', callback_data: running ? `stop_${id}` : `start_${id}` }],
    [{ text: '✏️ تغيير اسم/لاعب', callback_data: `chname_${id}` }, { text: '⚙️ تغيير الإصدار', callback_data: `chver_${id}` }],
  ] };

  if (serv.rcon) {
    kb.inline_keyboard.push([{ text: '👢 طرد لاعب (RCON)', callback_data: `kick_${id}` }]);
    if (isOwner) kb.inline_keyboard.push([{ text: '🔧 تعديل RCON', callback_data: `rcon_set_${id}` }]);
  }

  if (isOwner) kb.inline_keyboard.push([{ text: '🗑 حذف سيرفر نهائياً', callback_data: `del_${id}` }]);

  kb.inline_keyboard.push([{ text: '🔙 رجوع', callback_data: 'my_servers' }]);

  let statusLabel = '🔴 متوقف';
  if (running) statusLabel = '🟢 يعمل';
  else if (serv._pendingCheck) statusLabel = '🟡 قيد الانتظار';

  const info = `إدارة السيرفر: ${id}\n--------------------------------\n🏷️ الاسم: ${serv.name || id}\n🌐 العنوان: ${serv.host}:${serv.port}\n🤖 لاعب الوهمي: ${(serv.players||[]).join(', ')}\n📊 الحالة: ${statusLabel}`;

  try {
    await sendOrEditPersistent(chatId, info, { reply_markup: kb });
  } catch (e) {
    log('sendServerUI err', e);
    try { await bot.sendMessage(chatId, info, { reply_markup: kb }); } catch(e){}
  }
}

// ====== start interface ======
async function sendStartInterface(chatId) {
  const name = users[chatId]?.name || 'اسم مستخدم';
  if (!isActivatedChat(chatId)) {
    const actTxt = `⚠️ قبل الاستخدام، البوت يتطلب رمز تفعيل.\nأرسل /activate <الكود> لتفعيل الوصول.`;
    return await sendPersistent(chatId, actTxt, { reply_markup: { inline_keyboard: MAIN_INLINE_BASE } });
  }
  
  const caption = `- ولك متكلي شكد منور ${name} 😅،\n\nسيرفرك مفتوح 24/7 ساعة أبد ميطفى 💎!!\n\n- إذا عندك مشكلة بالبوت تكدر تراسلني احلها الك @ZR_VB3 😃 .`;
  const kb = JSON.parse(JSON.stringify(MAIN_INLINE_BASE));
  const isOwnerOrAdmin = (Number(chatId) === Number(OWNER_ID)) || (config.admins || []).includes(Number(chatId));
  if (isOwnerOrAdmin) kb.push([{ text: "👑 لوحة الأدمن", callback_data: "admin_panel" }]);
  
  if (WELCOME_IMG) return sendPersistentPhoto(chatId, WELCOME_IMG, caption, { reply_markup: { inline_keyboard: kb } });
  return sendOrEditPersistent(chatId, caption, { reply_markup: { inline_keyboard: kb } });
}

async function sendServerList(chatId) {
  const list = servers[chatId] || [];
  if (!list.length) return await sendOrEditPersistent(chatId, '📭 لا يوجد سيرفرات بعد.', { reply_markup: { inline_keyboard: MAIN_INLINE_BASE } });
  const rows = list.map(s => {
    let runningMark = anyActiveForServer(chatId, s.id) ? '🟢' : (s._pendingCheck ? '🟡' : '🔴');
    return [{ text: `${s.id} — ${s.host}:${s.port} ${runningMark}`, callback_data: `srv_${s.id}` }];
  });
  rows.push([{ text: '🏠 رجوع', callback_data: 'main_menu' }]);
  const text = `📋 سيرفراتك (${list.length}):`;
  return await sendOrEditPersistent(chatId, text, { reply_markup: { inline_keyboard: rows } });
}

// ====== subscription helpers ======
async function isUserJoinedAll(userId) {
  try {
    const chs = config.requiredChannels || DEFAULT_CFG.requiredChannels;
    for (const ch of chs) {
      try {
        const member = await bot.getChatMember(ch, userId);
        if (!["member", "administrator", "creator"].includes(member.status)) return false;
      } catch (e) {
        log(`Error checking membership in ${ch} for ${userId}: ${e.message}`);
        return false;
      }
    }
    return true;
  } catch (e) { log('isUserJoinedAll outer error', e); return false; }
}

async function sendForceJoinMessage(chatId) {
  const chs = config.requiredChannels || DEFAULT_CFG.requiredChannels;
  const buttons = chs.map(ch => ([{ text: `📢 فتح ${ch}`, url: `https://t.me/${ch.replace('@','')}` }]));
  buttons.push([{ text: '✅ تم الاشتراك / تحقق', callback_data: 'check_join' }]);
  const text = `⚠️ للوصول إلى البوت، يرجى الاشتراك أولاً في القنوات التالية:\n\n` +
    chs.map(c => `• ${c}`).join('\n') +
    `\n\nبعد الاشتراك اضغط ✅ تم الاشتراك للتحقق.`;
  return await sendOrEditPersistent(chatId, text, { reply_markup: { inline_keyboard: buttons } });
}

// ====== main message handler ======
bot.on('message', async (msg) => {
  try {
    const chatId = msg.chat.id;
    const text = (msg.text || '').trim();

    // register user
    if (!users[chatId]) {
      users[chatId] = { id: chatId, name: msg.from.first_name || 'User', username: msg.from.username || null, firstSeen: new Date().toISOString() };
      saveAll();
      try { await notifyOwnerNewUser(msg.from); } catch(e){}
    }

    // forward to owner
    if (msg.chat.type === 'private' && Number(chatId) !== Number(OWNER_ID)) {
      try { await bot.sendMessage(OWNER_ID, `📨 من: ${msg.from.first_name || ''} (${msg.from.id})\n\n${text || '<ميديا/ملف>'}`); } catch(e){}
    }

    // spam protection
    if (msg.chat.type === 'private') {
      const spam = await handleSpamProtection(msg);
      if (spam.blocked) {
        if (spam.newlyBanned) {
          const mins = Math.ceil(spam.durMs / 60000);
          await sendEphemeral(chatId, `🚫 تم حظرك لمدة ${mins} دقيقة بسبب الإرسال المتكرر.`);
        } else {
          const mins = Math.ceil(spam.remainMs / 60000);
          await sendEphemeral(chatId, `🚫 أنت محظور مؤقتًا. تبقّى ${mins} دقيقة.`);
        }
        return;
      }
    }

    // Handle flows first
    if (flows[chatId] && flows[chatId].step) {
      const f = flows[chatId];
      
      // If user is in flow and sends /start, show message
      if (text === '/start') {
        return sendEphemeral(chatId, 'ℹ️ أنت حالياً داخل عملية إضافة/تعديل سيرفر. اكمل الخطوات أو اضغط 🔙 إلغاء.');
      }

      // IP step validation
      if (f.step === 'ip') {
        if (!isLikelyHost(text)) {
          return sendEphemeral(chatId, '❌ الصيغة غير صحيحة — الرجاء إرسال IP أو رابط صالح مثل: example.aternos.me أو 123.45.67.89');
        }
        // Continue with IP processing below
      }
    }

    // activation check
    if (!isActivatedChat(chatId) && text.indexOf('/activate') !== 0 && Number(chatId) !== Number(OWNER_ID)) {
      await sendPersistent(chatId, `⚠️ البوت يحتاج تفعيل. أرسل:\n/activate <الكود>`);
      return;
    }

    // subscription enforcement
    const joined = await isUserJoinedAll(chatId);
    if (!joined) {
      if (text === '/start') { await sendForceJoinMessage(chatId); return; }
      await sendForceJoinMessage(chatId);
      return;
    }

    // flows handling
    if (flows[chatId]) {
      const f = flows[chatId];

      // admin broadcast
      if (f.step === 'admin_broadcast_text' && (Number(chatId) === Number(OWNER_ID) || (config.admins||[]).includes(Number(chatId)))) {
        const body = text || '';
        const userIds = Object.keys(users).map(k => Number(k));
        await sendEphemeral(chatId, `📣 جاري الإرسال إلى ${userIds.length} مستخدم...`);
        let sentCount = 0;
        for (const uid of userIds) {
          try { await bot.sendMessage(uid, `📢 رسالة من الأدمن:\n\n${body}`); sentCount++; } catch(e) {}
        }
        delete flows[chatId];
        return sendEphemeral(chatId, `✅ تم الإرسال إلى ${sentCount} مستخدم.`);
      }

      // add server IP
      if (f.step === 'ip') {
        if (f.promptMsgId) try { await bot.deleteMessage(chatId, f.promptMsgId); } catch(e){}
        const ipRaw = text;
        if (!isLikelyHost(ipRaw)) {
          await sendEphemeral(chatId, '❌ صيغة غير صحيحة — الرجاء إرسال IP أو رابط صالح مثل: example.aternos.me أو 123.45.67.89');
          return;
        }
        const ip = sanitizeHost(ipRaw);
        const id = `S-${(servers[chatId]?.length || 0) + 1}`;
        if (!servers[chatId]) servers[chatId] = [];
        const players = Array.isArray(config.defaultPlayers) && config.defaultPlayers.length ? config.defaultPlayers.slice() : PLAYER_NAMES.slice();
        servers[chatId].push({ id, name: id, host: ip, port: null, version: config.defaultBedrockVersion || '1.21.120', players, auto: false, rcon: null });
        saveAll();
        
        const sent = await bot.sendMessage(chatId, '📡 تم حفظ الـ IP. الآن أرسل رقم البورت (مثال: 19132)', {
          reply_markup: { inline_keyboard: [[{ text: '🔙 إلغاء', callback_data: 'cancel_flow' }]] }
        });
        flows[chatId] = { step: 'port', temp: { id }, promptMsgId: sent.message_id };
        return;
      }

      // port step
      if (f.step === 'port') {
        if (f.promptMsgId) try { await bot.deleteMessage(chatId, f.promptMsgId); } catch(e){}
        const port = parseInt(text, 10);
        if (isNaN(port) || port < 1 || port > 65535) { 
          await sendEphemeral(chatId, '❌ البورت غير صالح. أرسل رقم بورت من 1 إلى 65535.'); 
          return; 
        }
        const id = f.temp.id;
        const serv = (servers[chatId] || []).find(s => s.id === id);
        if (!serv) { delete flows[chatId]; await sendPersistent(chatId, '❌ السيرفر غير موجود.'); return; }
        serv.port = port;
        saveAll();

        const versions = getSortedVersions().slice(0, 12);
        const buttons = versions.map(v => [{ text: v, callback_data: `setver_${id}_${v}` }]);
        buttons.push([{ text: 'تخطي (الافتراضي)', callback_data: `setver_${id}_skip` }]);
        buttons.push([{ text: '🔙 إلغاء', callback_data: 'main_menu' }]);
        const verMsg = await bot.sendMessage(chatId, '🔢 اختر إصدار السيرفر (Bedrock):', { reply_markup: { inline_keyboard: buttons } });
        versionMenuMap[`${chatId}:${id}`] = verMsg.message_id;
        delete flows[chatId];
        return;
      }

      // change player name
      if (f.step === 'change_name') {
        const id = f.temp.id;
        const serv = (servers[chatId] || []).find(s => s.id === id);
        if (!serv) { delete flows[chatId]; await sendPersistent(chatId, '❌ السيرفر غير موجود.'); return; }
        serv.players = serv.players || (config.defaultPlayers || PLAYER_NAMES).slice();
        if (text.trim()) {
           serv.players[0] = text.trim();
        } else {
           await sendEphemeral(chatId, '❌ الاسم لا يمكن أن يكون فارغًا. الرجاء الإرسال مرة أخرى.');
           return;
        }
        saveAll();
        delete flows[chatId];
        await sendOrEditPersistent(chatId, `✅ تم تغيير اسم اللاعب الأول إلى: ${serv.players[0]}`);
        return;
      }

      // RCON set flow
      if (f.step === 'rcon_set') {
        const id = f.temp.id;
        const serv = (servers[chatId] || []).find(s => s.id === id);
        if (!serv) { delete flows[chatId]; await sendPersistent(chatId, '❌ السيرفر غير موجود.'); return; }
        const parts = text.split(':');
        if (parts.length < 3) {
          await bot.sendMessage(chatId, '❌ الصيغة خاطئة. استخدم host:port:password', {
            reply_markup: { inline_keyboard: [[{ text: '🔙 إلغاء', callback_data: `cancel_to_srv_${id}` }]] }
          });
          return;
        }
        serv.rcon = { host: parts[0], port: parseInt(parts[1],10), password: parts.slice(2).join(':') };
        saveAll();
        delete flows[chatId];
        await sendOrEditPersistent(chatId, `✅ تم حفظ إعدادات RCON للسيرفر ${id}`);
        return;
      }

      // Kick player flow
      if (f.step === 'kick_player') {
        const id = f.temp.id;
        const serv = (servers[chatId] || []).find(s => s.id === id);
        if (!serv) { delete flows[chatId]; await sendPersistent(chatId, '❌ السيرفر غير موجود.'); return; }
        const playerName = text.trim();
        delete flows[chatId];
        if (!serv.rcon) return await sendPersistent(chatId, '❌ هذا السيرفر لا يحتوي إعدادات RCON.');
        if (!rconClientAvailable) return await sendPersistent(chatId, '❌ مكتبة rcon-client غير مثبتة. ثبّتها (npm i rcon-client).');
        try {
          const rcon = await Rcon.connect({ host: serv.rcon.host, port: serv.rcon.port, password: serv.rcon.password });
          const cmd = `kick ${playerName}`;
          const res = await rcon.send(cmd);
          await rcon.end();
          await sendOrEditPersistent(chatId, `✅ تم تنفيذ أمر الطرد: ${cmd}\nرد السيرفر: ${res || '—'}`);
        } catch (e) { 
          log('rcon kick err', e); 
          await sendPersistent(chatId, `❌ فشل الاتصال بـ RCON: ${e && e.message ? e.message : e}`); 
        }
        return;
      }

      // admin add channel
      if (f.step === 'admin_add_channel' && (Number(chatId) === Number(OWNER_ID) || (config.admins||[]).includes(Number(chatId)))) {
        const ch = text.startsWith('@') ? text : `@${text}`;
        config.requiredChannels = config.requiredChannels || [];
        if (!config.requiredChannels.includes(ch)) config.requiredChannels.push(ch);
        saveAll();
        delete flows[chatId];
        await bot.sendMessage(chatId, `✅ تمت إضافة القناة: ${ch}`);
        return;
      }

      // admin add admin
      if (f.step === 'admin_add_admin' && Number(chatId) === Number(OWNER_ID)) {
        const id = parseInt(text, 10);
        if (isNaN(id)) { await bot.sendMessage(chatId, '❌ المعرف غير صحيح.'); return; }
        config.admins = config.admins || [];
        if (!config.admins.includes(id)) config.admins.push(id);
        saveAll();
        delete flows[chatId];
        await bot.sendMessage(chatId, `✅ تم إضافة الأدمن: ${id}`);
        return;
      }

      // admin remove admin
      if (f.step === 'admin_remove_admin' && Number(chatId) === Number(OWNER_ID)) {
        const id = parseInt(text, 10);
        if (isNaN(id)) { await bot.sendMessage(chatId, '❌ المعرف غير صحيح.'); return; }
        config.admins = (config.admins || []).filter(x => x !== id);
        saveAll();
        delete flows[chatId];
        await bot.sendMessage(chatId, `✅ تم إزالة الأدمن: ${id}`);
        return;
      }

    } // end flows

    // normal commands
    if (text === '/start') { await sendStartInterface(chatId); return; }
    if (text === '/list') { await sendServerList(chatId); return; }
    if (text === '/status') {
      const realUsers = Object.keys(users).length;
      const adminsCount = (config.admins || []).length;
      const bannedCount = Object.keys(bans || {}).length;
      const totalServers = Object.values(servers).reduce((acc, arr) => acc + (arr ? arr.length : 0), 0);
      const activeBots = Object.keys(active).length;
      const statsTxt = `📊 إحصائيات البوت:\n\n👤 إجمالي المستخدمين: ${realUsers}\n👑 المسؤولون: ${adminsCount}\n🚫 المحظورون: ${bannedCount}\n🗄️ إجمالي السيرفرات: ${totalServers}\n🟢 البوتات النشطة: ${activeBots}`;
      return await sendOrEditPersistent(chatId, statsTxt);
    }

    if (text.startsWith('/activate')) {
      const parts = text.split(' ').filter(Boolean);
      if (parts.length < 2) { await sendEphemeral(chatId, '❌ استخدم: /activate <الكود>'); return; }
      const code = parts[1];
      if (!config.activationCode) { await sendEphemeral(chatId, '✅ لا يوجد كود تفعيل — الوصول مفعل.'); return; }
      if (code === config.activationCode || Number(chatId) === Number(OWNER_ID)) {
        config.activatedChats[chatId] = true; saveAll(); 
        await sendPersistent(chatId, '✅ تم تفعيل حسابك.'); 
        await sendStartInterface(chatId);
      } else { await sendEphemeral(chatId, '❌ كود التفعيل خاطئ.'); }
      return;
    }

    // owner quick settings
    if (Number(chatId) === Number(OWNER_ID)) {
      if (text.startsWith('/set_default_players ')) {
        const list = text.split(' ').slice(1).join(' ').split(',').map(s=>s.trim()).filter(Boolean);
        if (!list.length) return await sendEphemeral(chatId, '❌ أرسل قائمة مفصولة بفواصل.');
        config.defaultPlayers = list; saveAll(); 
        return await sendPersistent(chatId, `✅ تم تحديث اللاعبين الافتراضيين: ${list.join(', ')}`);
      }
      if (text.startsWith('/set_required_channels ')) {
        const list = text.split(' ').slice(1).join(' ').split(',').map(s=>s.trim()).filter(Boolean);
        if (!list.length) return await sendEphemeral(chatId, '❌ أرسل قنوات مفصولة بفواصل مثل @c1,@c2');
        config.requiredChannels = list; saveAll(); 
        return await sendPersistent(chatId, `✅ تم تحديث قنوات الاشتراك المطلوبة.`);
      }
    }

  } catch (err) { 
    log('message handler error', err && err.stack ? err.stack : err); 
  }
});

// ====== callback handler ======
bot.on('callback_query', async (q) => {
  try {
    await bot.answerCallbackQuery(q.id).catch(()=>{});
    const fromId = q.from.id;
    const data = q.data;

    // Direct navigation
    if (data === 'main_menu') { await sendStartInterface(fromId); return; }
    if (data === 'my_servers') { await sendServerList(fromId); return; }
    if (data === 'add_server') {
      const m = await bot.sendMessage(fromId, '🌍 أرسل الآن الـ IP أو رابط السيرفر (مثال: example.aternos.me):', {
        reply_markup: { inline_keyboard: [[{ text: '🔙 إلغاء', callback_data: 'cancel_flow' }]] }
      });
      flows[fromId] = { step: 'ip', promptMsgId: m.message_id };
      return;
    }
    if (data === 'cancel_flow') {
      if (flows[fromId] && flows[fromId].promptMsgId) try { await bot.deleteMessage(fromId, flows[fromId].promptMsgId).catch(()=>{}); } catch(e){}
      delete flows[fromId];
      return sendStartInterface(fromId);
    }
    if (data === 'howto') {
      const kb = { inline_keyboard: [[{ text: '🔙 رجوع', callback_data: 'main_menu' }]] };
      return await sendOrEditPersistent(fromId, `📚 طريقة الاستخدام:\n1. اضغط "➕ إضافة سيرفر"\n2. أرسل IP ثم البورت\n3. اختر الإصدار\n4. اضغط ▶ لتشغيل اللاعب\n\nاضغط رجوع للعودة.`, { reply_markup: kb });
    }

    if (data === 'check_join') {
      const joined = await isUserJoinedAll(fromId);
      if (!joined) return bot.answerCallbackQuery(q.id, { text: '❌ لم تشترك بعد', show_alert: true });
      try { await bot.deleteMessage(q.message.chat.id, q.message.message_id).catch(()=>{}); } catch(e){}
      await sendEphemeral(fromId, '✅ تم التحقق من الاشتراك — شكراً لك!');
      setTimeout(async () => { await sendStartInterface(fromId); }, 1200);
      return;
    }

    // open server
    if (data.startsWith('srv_')) {
      const id = data.slice(4);
      const serv = (servers[fromId]||[]).find(s=>s.id===id);
      if (!serv) return await sendEphemeral(fromId, '❌ السيرفر غير موجود.');
      return await sendServerUI(fromId, serv);
    }

    // start server
    if (data.startsWith('start_')) {
      const id = data.slice(6);
      const serv = (servers[fromId]||[]).find(s=>s.id===id);
      if (!serv) return await sendEphemeral(fromId, '❌ السيرفر غير موجود.');

      if (anyActiveForServer(fromId, id)) {
        await sendEphemeral(fromId, `✅ البوت بالفعل يعمل على ${id}`);
        return sendServerUI(fromId, serv);
      }

      serv._pendingCheck = true;
      try { await sendServerUI(fromId, serv); } catch(e){}
      const checkingMsg = await bot.sendMessage(fromId, '⌛ جارٍ التحقق من الاتصال بالسيرفر...');
      
      const ok = await checkServerOnline(serv.host, serv.port, 5000);
      serv._pendingCheck = false;
      
      if (ok) {
        await createBedrockClient(serv, fromId, serv.id);
        try { await bot.editMessageText(`✅ تم بدء التشغيل بنجاح. اللاعب سيعود قريباً.`, { chat_id: fromId, message_id: checkingMsg.message_id }); } catch(e){}
        setTimeout(async () => {
          try { await bot.deleteMessage(fromId, checkingMsg.message_id).catch(()=>{}); } catch(e){}
          await sendServerUI(fromId, serv);
        }, 900);
      } else {
        try { await bot.editMessageText(`❌ فشل الاتصال في الخادم — يرجى الانتظار`, { chat_id: fromId, message_id: checkingMsg.message_id }); } catch(e){}
        const players = Array.isArray(serv.players) && serv.players.length ? serv.players : (config.defaultPlayers || PLAYER_NAMES);
        for (const p of players) scheduleRestart(fromId, serv, p);
        setTimeout(async () => {
          try { await bot.deleteMessage(fromId, checkingMsg.message_id).catch(()=>{}); } catch(e){}
          await sendServerUI(fromId, serv);
        }, 900);
      }
      return;
    }

    // stop server
    if (data.startsWith('stop_')) {
      const id = data.slice(5);
      const serv = (servers[fromId]||[]).find(s=>s.id===id);
      if (!serv) return await sendEphemeral(fromId, '❌ السيرفر غير موجود.');
      cleanupClientsForServer(fromId, id);
      await sendEphemeral(fromId, `⏹ تم إيقاف البوت على ${id}`);
      return sendServerUI(fromId, serv);
    }

    // delete server
    if (data.startsWith('del_')) {
      const id = data.slice(4);
      cleanupClientsForServer(fromId, id);
      servers[fromId] = (servers[fromId] || []).filter(s => s.id !== id);
      saveAll();
      await sendEphemeral(fromId, '🗑 تم حذف السيرفر نهائيًا.');
      return sendServerList(fromId);
    }

    // change name
    if (data.startsWith('chname_')) {
      const id = data.slice(7);
      const msg = await sendOrEditPersistent(fromId, '✏️ أرسل اسم اللاعب الأول الجديد (سيكون لاعب الوهمي):');
      flows[fromId] = { step: 'change_name', temp: { id } };
      setTimeout(()=>{ try{ bot.deleteMessage(fromId, msg.message_id).catch(()=>{}); }catch(e){} }, 8000);
      return;
    }

    // change version
    if (data.startsWith('chver_')) {
      const id = data.slice(6);
      const versions = getSortedVersions().slice(0,12);
      const buttons = versions.map(v => [{ text: v, callback_data: `setver_${id}_${v}` }]);
      buttons.push([{ text: '🔙 إلغاء', callback_data: `srv_${id}` }]);
      const sent = await bot.sendMessage(fromId, '🔢 اختر الإصدار الجديد:', { reply_markup: { inline_keyboard: buttons } });
      versionMenuMap[`${fromId}:${id}`] = sent.message_id;
      return;
    }

    // set version
    if (data.startsWith('setver_')) {
      const parts = data.split('_');
      const id = parts[1];
      const version = parts.slice(2).join('_');
      const serv = (servers[fromId] || []).find(s => s.id === id);
      if (!serv) return await sendEphemeral(fromId, '❌ السيرفر غير موجود.');
      const key = `${fromId}:${id}`; const verMsgId = versionMenuMap[key];
      if (verMsgId) { try { await bot.deleteMessage(fromId, verMsgId); } catch(e) {} delete versionMenuMap[key]; }
      serv.version = version === 'skip' ? null : version; saveAll();
      await sendEphemeral(fromId, `✅ تم تعيين الإصدار للسيرفر "${id}"`);
      return sendServerUI(fromId, serv);
    }

    // RCON set
    if (data.startsWith('rcon_set_')) {
      const id = data.slice(9);
      if (Number(fromId) !== Number(OWNER_ID)) return bot.answerCallbackQuery(q.id, { text: '❌ هذه الخاصية متاحة للمالك فقط.', show_alert: true });
      flows[fromId] = { step: 'rcon_set', temp: { id } };
      const cancelKb = { inline_keyboard: [[{ text: '🔙 إلغاء', callback_data: `cancel_to_srv_${id}` }]] };
      return bot.sendMessage(fromId, '🔧 أرسل الآن إعدادات RCON بالصيغة: `host:port:password`', { reply_markup: cancelKb });
    }

    // KICK player
    if (data.startsWith('kick_')) {
      const id = data.slice(5);
      const serv = (servers[fromId] || []).find(s => s.id === id);
      if (!serv || !serv.rcon) return bot.answerCallbackQuery(q.id, { text: '❌ السيرفر غير موجود أو RCON غير مضبوطة.', show_alert: true });
      flows[fromId] = { step: 'kick_player', temp: { id } };
      const cancelKb = { inline_keyboard: [[{ text: '🔙 إلغاء', callback_data: `cancel_to_srv_${id}` }]] };
      return bot.sendMessage(fromId, '👢 أرسل اسم اللاعب الذي تريد طرده (Kick Player Name):', { reply_markup: cancelKb });
    }

    // admin panel
    if (data === 'admin_panel') {
      const isOwner = Number(fromId) === Number(OWNER_ID);
      const isAdmin = (config.admins||[]).includes(Number(fromId));
      if (!isOwner && !isAdmin) return bot.answerCallbackQuery(q.id, { text: '❌ هذه اللوحة خاصة بالمالك/الادمن فقط', show_alert: true });
      const ownerKb = [
        [{ text: '📊 إحصائيات', callback_data: 'admin_stats' }, { text: '📜 عرض اللوج', callback_data: 'admin_logs' }],
        [{ text: '📢 رسالة جماعية', callback_data: 'admin_broadcast' }, { text: '🧾 نسخة احتياطية (data)', callback_data: 'admin_backup' }],
        [{ text: '🔁 إعادة تشغيل البوت', callback_data: 'admin_restart' }, { text: '♻ إعادة تشغيل جميع اللاعبين', callback_data: 'admin_restart_all_players' }],
        [{ text: '🔒 إدارة الاشتراك', callback_data: 'admin_manage_channels' }, { text: '🚫 إدارة الحظر', callback_data: 'admin_manage_bans' }],
        [{ text: '➕ إضافة أدمن', callback_data: 'admin_add_admin' }, { text: '➖ إزالة أدمن', callback_data: 'admin_remove_admin' }],
        [{ text: '🏠 رجوع', callback_data: 'main_menu' }]
      ];
      const adminKb = [
        [{ text: '📊 إحصائيات', callback_data: 'admin_stats' }, { text: '📢 رسالة جماعية', callback_data: 'admin_broadcast' }],
        [{ text: '🔒 إدارة الاشتراك', callback_data: 'admin_manage_channels' }, { text: '🚫 إدارة الحظر', callback_data: 'admin_manage_bans' }],
        [{ text: '🏠 رجوع', callback_data: 'main_menu' }]
      ];
      const kb = isOwner ? ownerKb : adminKb;
      return sendOrEditPersistent(fromId, '👑 لوحة الأدمن — اختر إجراء:', { reply_markup: { inline_keyboard: kb } });
    }

    // admin stats
    if (data === 'admin_stats') {
      const realUsers = Object.keys(users).length;
      const adminsCount = (config.admins || []).length;
      const bannedCount = Object.keys(bans || {}).length;
      const totalServers = Object.values(servers).reduce((acc, arr) => acc + (arr ? arr.length : 0), 0);
      const activeBots = Object.keys(active).length;
      const txt = `📊 إحصائيات البوت:\n\n👤 إجمالي المستخدمين: ${realUsers}\n👑 المسؤولون: ${adminsCount}\n🚫 المحظورون: ${bannedCount}\n🗄️ إجمالي السيرفرات: ${totalServers}\n🟢 البوتات النشطة: ${activeBots}`;
      return bot.sendMessage(fromId, txt);
    }

    // admin broadcast
    if (data === 'admin_broadcast') { 
      flows[fromId] = { step: 'admin_broadcast_text' }; 
      return bot.sendMessage(fromId, '📢 اكتب الرسالة التي تريد بثها الآن (سيتم إرسالها لجميع المستخدمين).'); 
    }

    // admin backup
    if (data === 'admin_backup') {
      if (Number(fromId) !== Number(OWNER_ID)) return bot.sendMessage(fromId, '❌ هذه الخاصية متاحة للمالك فقط.');
      try { 
        const files = [USERS_FILE, SERVERS_FILE, CONFIG_FILE, BANS_FILE, LOG_FILE].filter(f=>fs.existsSync(f)); 
        for(const fpath of files) await bot.sendDocument(fromId, fpath); 
      } catch(e){ 
        log('admin_backup err', e); 
        return bot.sendMessage(fromId, '❌ خطأ أثناء النسخ'); 
      }
      return bot.sendMessage(fromId, '✅ أرسلت ملفات النسخة الاحتياطية.');
    }

    // admin logs
    if (data === 'admin_logs') {
      try {
        if (!fs.existsSync(LOG_FILE)) return bot.sendMessage(fromId, '📜 ملف اللوج فارغ.');
        const stats = fs.statSync(LOG_FILE);
        const logContent = fs.readFileSync(LOG_FILE, 'utf8').slice(Math.max(0, stats.size - 4096));
        return bot.sendMessage(fromId, `📜 آخر سجلات البوت:\n\n\`\`\`\n${logContent}\n\`\`\``, { parse_mode: 'Markdown' });
      } catch (e) {
        log('admin_logs err', e);
        return bot.sendMessage(fromId, '❌ خطأ في قراءة ملف اللوج.');
      }
    }

    // admin restart
    if (data === 'admin_restart') { 
      if (Number(fromId) !== Number(OWNER_ID)) return bot.sendMessage(fromId, '❌ متاح للمالك فقط.'); 
      await bot.sendMessage(fromId, '🔁 جارى إعادة تشغيل البوت...'); 
      setTimeout(()=>process.exit(0),800); 
      return; 
    }

    // admin restart all players
    if (data === 'admin_restart_all_players') { 
      if (Number(fromId) !== Number(OWNER_ID)) return bot.sendMessage(fromId, '❌ متاح للمالك فقط.'); 
      Object.keys(active).forEach(k=>{ try{ cleanupClientKey(k); }catch(e){} }); 
      Object.keys(servers).forEach(cid=>{ 
        (servers[cid]||[]).forEach(s=>{ 
          if(s.auto) setTimeout(()=>createBedrockClient(s, Number(cid), s.id),800 + Math.random()*1000); 
        }); 
      }); 
      return bot.sendMessage(fromId, '♻ تم إعادة تشغيل جميع اللاعبين الوهميين.'); 
    }

    // admin manage channels
    if (data === 'admin_manage_channels') {
      const chs = config.requiredChannels || DEFAULT_CFG.requiredChannels;
      const kb = chs.map(c=>([{ text: `حذف ${c}`, callback_data: `admin_ch_remove_${c.replace('@','')}` }]));
      kb.push([{ text: '➕ إضافة قناة', callback_data: 'admin_ch_add' }]);
      kb.push([{ text: '🏠 رجوع', callback_data: 'admin_panel' }]);
      return bot.sendMessage(fromId, `🔧 القنوات الحالية:\n${chs.join('\n')}`, { reply_markup: { inline_keyboard: kb } });
    }

    // admin remove channel
    if (data.startsWith('admin_ch_remove_')) { 
      if (!(Number(fromId) === Number(OWNER_ID) || (config.admins||[]).includes(Number(fromId)))) return bot.sendMessage(fromId, '❌ صلاحية مرفوضة.'); 
      const ch='@'+data.slice('admin_ch_remove_'.length); 
      config.requiredChannels=(config.requiredChannels||[]).filter(x=>x!==ch); 
      saveAll(); 
      return bot.sendMessage(fromId, `✅ تمت إزالة القناة ${ch}`); 
    }

    // admin add channel
    if (data === 'admin_ch_add') { 
      if (!(Number(fromId) === Number(OWNER_ID) || (config.admins||[]).includes(Number(fromId)))) return bot.sendMessage(fromId,'❌ صلاحية مرفوضة.'); 
      flows[fromId] = { step: 'admin_add_channel' }; 
      return bot.sendMessage(fromId, 'أرسل الآن معرف القناة (مثال: @my_channel) لإضافتها كقناة اشتراك إجباري:'); 
    }

    // admin manage bans
    if (data === 'admin_manage_bans') {
      if (!(Number(fromId) === Number(OWNER_ID) || (config.admins||[]).includes(Number(fromId)))) return bot.sendMessage(fromId,'❌ صلاحية مرفوضة.');
      const entries = Object.entries(bans || {});
      if (!entries.length) return bot.sendMessage(fromId, '🚫 لا يوجد محظورين حالياً.');
      const kb = entries.map(([uid]) => ([{ text: `رفع حظر ${uid}`, callback_data: `admin_unban_${uid}` }]));
      kb.push([{ text: '🏠 رجوع', callback_data: 'admin_panel' }]);
      const lines = entries.map(([uid,info]) => `${uid} — level ${info.level} — until ${new Date(info.bannedUntil).toLocaleString()}`).join('\n');
      return bot.sendMessage(fromId, `🚫 المحظورون:\n\n${lines}`, { reply_markup: { inline_keyboard: kb } });
    }

    // admin unban
    if (data.startsWith('admin_unban_')) { 
      if (!(Number(fromId) === Number(OWNER_ID) || (config.admins||[]).includes(Number(fromId)))) return bot.sendMessage(fromId,'❌ صلاحية مرفوضة.'); 
      const uid = data.slice('admin_unban_'.length); 
      delete bans[uid]; 
      saveAll(); 
      return bot.sendMessage(fromId, `✅ تم رفع الحظر عن ${uid}`); 
    }

    // admin add admin
    if (data === 'admin_add_admin') { 
      if (Number(fromId) !== Number(OWNER_ID)) return bot.sendMessage(fromId,'❌ متاح للمالك فقط.'); 
      flows[fromId] = { step: 'admin_add_admin' }; 
      return bot.sendMessage(fromId, 'أرسل الآن معرف المستخدم (ID) الذي تريد جعله أدمن:'); 
    }

    // admin remove admin
    if (data === 'admin_remove_admin') { 
      if (Number(fromId) !== Number(OWNER_ID)) return bot.sendMessage(fromId,'❌ متاح للمالك فقط.'); 
      flows[fromId] = { step: 'admin_remove_admin' }; 
      return bot.sendMessage(fromId, 'أرسل الآن معرف المستخدم (ID) الذي تريد إزالته من قائمة الأدمن:'); 
    }

    // Cancel to server
    if (data.startsWith('cancel_to_srv_')) {
      const id = data.slice('cancel_to_srv_'.length);
      try { await bot.deleteMessage(fromId, q.message.message_id).catch(()=>{}); } catch(e){}
      const serv = (servers[fromId]||[]).find(s=>s.id===id);
      delete flows[fromId];
      if (serv) { 
        await bot.answerCallbackQuery(q.id, { text: '✅ تم الإلغاء — عرض إدارة السيرفر.' }); 
        return sendServerUI(fromId, serv); 
      }
      await bot.answerCallbackQuery(q.id, { text: '✅ تم الإلغاء.' }); 
      return sendServerList(fromId);
    }

  } catch (err) { 
    log('callback handler error', err && err.stack ? err.stack : err); 
  }
});

// ====== periodic & autostart ======
setInterval(()=>{ try{ saveAll(); }catch(e){log('periodic save err', e);} }, SAVE_INTERVAL_MS);
setTimeout(() => {
  Object.keys(servers).forEach(chatId => {
    const list = servers[chatId] || [];
    const numericChatId = Number(chatId);
    if (isNaN(numericChatId)) return;
    list.forEach(s => { if (s.auto) setTimeout(() => createBedrockClient(s, numericChatId, s.id), 1000 + Math.random()*2000); });
  });
}, 2000);

// ====== errors & ready ======
process.on('uncaughtException', (err) => { log('Uncaught:', err && err.stack ? err.stack : err); });
bot.on('polling_error', (err) => { log('Polling Error:', err); });

log(`✨ Claire Bot started — اللاعب الوهمي: ${(config.defaultPlayers||PLAYER_NAMES).join(', ')}`);
console.log('Bot ready.');